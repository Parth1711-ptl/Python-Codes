words = ["hello", "there", "santa"]
s = set()

for i in words:
    s.add(i.upper())

print(s)