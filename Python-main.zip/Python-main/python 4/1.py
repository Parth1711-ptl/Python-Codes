def print_uppercase_a_to_z():
    for char in range(ord('a'), ord('z') + 1):
        print(chr(char).upper())

print_uppercase_a_to_z()