strings = ["hello", "world", "raju", "nice", "bad"]
upper = [i.upper() for i in strings]

print(upper)