#program 13
a=int(input("enter byts"))
b=a/1024
print("convert in kb",b)
c=b/1024
print("convert in mb",c)
d=c/1024
print("convert in gb",d)

