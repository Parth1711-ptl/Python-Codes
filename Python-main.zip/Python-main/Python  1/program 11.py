#program 11
a=int(input("enter grams"))
b=a/1000
print("convert in kg",b)
