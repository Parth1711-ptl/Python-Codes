
# program 24
a = int(input("Enter the value for a: "))
b = int(input("Enter the value for b: "))
a, b = b, a

print("After swapping:")
print("a =", a)
print("b =", b)