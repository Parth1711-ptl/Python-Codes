# Program 20
base = float(input("Enter base of the triangle: "))
height = float(input("Enter height of the triangle: "))
area = 0.5 * base * height
print("Area of the triangle is", area)
