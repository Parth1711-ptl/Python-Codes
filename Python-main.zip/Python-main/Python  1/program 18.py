#program 18
length = float(input("Enter the length of the rectangle: "))
width = float(input("Enter the width of the rectangle: "))
area = length * width
perimeter = 2 * (length + width)
print("Area of the rectangle is", area)
print("Perimeter of the rectangle is", perimeter)
