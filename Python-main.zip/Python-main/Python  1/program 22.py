# progran 22
gross_sales = float(input("Enter the gross sales amount: "))
discount = gross_sales * 0.10
net_sales = gross_sales - discount
print("Net Sales: ", net_sales)