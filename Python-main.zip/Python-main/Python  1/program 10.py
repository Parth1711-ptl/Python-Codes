#program 10
a=float(input("enter dollar"))
b=a*48
c=b/70
print(c)
