#program 14
a=float(input("enter celcius"))
b=9/5*a+32
print("fahrenheit is",b)