#program 8
a=float(input("enter dollar"))
b=a*48
print("convert in inr",b )
