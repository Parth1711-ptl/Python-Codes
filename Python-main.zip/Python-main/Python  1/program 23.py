# program 23
subject1 = float(input("Enter marks for subject 1: "))
subject2 = float(input("Enter marks for subject 2: "))
subject3 = float(input("Enter marks for subject 3: "))
total = subject1 + subject2 + subject3
average = total / 3
print("Total marks: ", total)
print("Average marks: ", average)