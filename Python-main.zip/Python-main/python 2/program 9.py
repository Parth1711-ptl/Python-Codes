a=int(input("Enter your number: "))
print("Number =",a)

if(a>=0):
    print("Absoulte value =", a)
else:
    a=a*-1
    print("Absoulte value =", a)
