a=int(input("Enter your first number (a): "))
b=int(input("Enter your second number (b): "))
print("a =",a)
print("b =",b)

if(a>b):
    print(a, "is the largest number")
else:
    print(b, "is the largest number")

if(a<b):
    print(a, "is the smallest number")
else:
    print(b, "is the smallest number")
