a=int(input("Enter your number: "))
print("number =",a)

if(a%2==0):
    print(a, "is even")
else:
    print(a, "is odd")
