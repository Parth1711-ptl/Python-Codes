a=int(input("Enter your age (years): "))
print("Age =",a)

if(a>=18):
    print("You are an adult (Major).")
else:
    print("You are a Minor!!!")
