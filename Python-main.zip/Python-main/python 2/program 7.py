a=int(input("Enter your year: "))
print("Year =",a)

if(a%4==0):
    print(a, "is a leap year")
else:
    print(a, "is not a leap year")
