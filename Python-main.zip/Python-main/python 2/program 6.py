a=input("Enter your number only number not a string : ")
print(len(a))