a=int(input("Enter your number: "))
print("number =",a)

if(a%10==0):
    print(a, "is divisible by 10")
else:
    print(a, "is not divisible by 10")
