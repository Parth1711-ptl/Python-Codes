tup = (1, 2, 3, 4)
print(tup)
lis = list(tup)
lis[1] = 20
tup = tuple(lis)
print(tup)