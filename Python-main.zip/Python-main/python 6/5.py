list = [(), (1, 2), (), (3, 4, 5), (), (6, 7, 8, 9)]

filtered = [t for t in list if t]

print(filtered)